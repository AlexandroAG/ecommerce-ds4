package com.alex.ds4.Product;

import com.alex.ds4.Category.Category;
import java.util.List;

public class ProductService {

    private final ProductRepository productRepository;

    public ProductService() {
        this.productRepository = new ProductRepository();
    }

    public List<Product> searchProducts(String search, String category, String sort) {
        return productRepository.searchProducts(search, category, sort);
    }

    public List<Category> getCategories() {
        return productRepository.getCategories();
    }

    public byte[] getProductImage(int productId) {
        return productRepository.getProductImage(productId);
    }

    public Product getProductById(int productId) {
        return productRepository.getProductById(productId);
    }

    public boolean updateStock(int productId, int newStock) {
        return productRepository.updateStock(productId, newStock);
    }

    public boolean addProduct(Product product) {
        return productRepository.addProduct(product);
    }

    public static List<Product> searchProductsStatic(String search, String category, String sort) {
        ProductService service = new ProductService();
        return service.searchProducts(search, category, sort);
    }

    public static List<Category> getCategoriesStatic() {
        ProductService service = new ProductService();
        return service.productRepository.getCategories();
    }

}
