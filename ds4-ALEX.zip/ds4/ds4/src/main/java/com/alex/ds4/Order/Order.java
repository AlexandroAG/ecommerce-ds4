package com.alex.ds4.Order;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private int userId;
    private LocalDateTime creationDate;

    private BigDecimal totalAmount;
    private BigDecimal vat;

    private String shippingAddress;
    private String username;
    private String paymentMethod;
    private String formattedDate;
    private int paymentMethodId;

    public Order(int userId, BigDecimal totalAmount, BigDecimal vat, String shippingAddress, int paymentMethodId) {
        this.userId = userId;
        this.totalAmount = totalAmount;
        this.vat = vat;
        this.shippingAddress = shippingAddress;
        this.paymentMethodId = paymentMethodId;
    }
    
    public Order(int id, String username, BigDecimal totalAmount, BigDecimal vat, String shippingAddress, String paymentMethod, LocalDateTime creationDate) {
        this.id = id;
        this.username = username;
        this.totalAmount = totalAmount;
        this.vat = vat;
        this.shippingAddress = shippingAddress;
        this.paymentMethod = paymentMethod;
        this.formattedDate = formatCreationDate(creationDate);
    }

    public Order(BigDecimal totalAmount, BigDecimal vat, String shippingAddress, int paymentMethodId) {
        this.totalAmount = totalAmount;
        this.vat = vat;
        this.shippingAddress = shippingAddress;
        this.paymentMethodId = paymentMethodId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
        this.formattedDate = formatCreationDate(creationDate);
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getVat() {
        return vat;
    }

    public void setVat(BigDecimal vat) {
        this.vat = vat;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public int getPaymentMethodId() {
        return paymentMethodId;
    }

    public void setPaymentMethodId(int paymentMethodId) {
        this.paymentMethodId = paymentMethodId;
    }
    
    
    
    private String formatCreationDate(LocalDateTime creationDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return creationDate.format(formatter);
    }

    public String getFormattedDate() {
        return formattedDate;
    }

}
