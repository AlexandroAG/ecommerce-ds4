package com.alex.ds4.User;

import com.alex.ds4.resources.dbConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

@WebServlet("/registerUser")
public class UserRegisterServlet extends HttpServlet {

    private final UserService userService;
    private final UserRepository userRepository;

    public UserRegisterServlet() {
        this.userService = new UserService();
        this.userRepository = new UserRepository();  
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String password = request.getParameter("password");

        if (username == null || email == null || password == null || username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            request.setAttribute("message", "Todos los campos son obligatorios.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        String fieldInUse = null;

        try (Connection connection = dbConnection.getConnection()) {  
            if (userRepository.isUsernameExist(connection, username)) {
                fieldInUse = "El nombre de usuario ya está en uso.";
            } else if (userRepository.isEmailExist(connection, email)) {
                fieldInUse = "El correo electrónico ya está en uso.";
            }
        } catch (SQLException e) {
            request.setAttribute("message", "Error al verificar los datos. Intenta nuevamente.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        if (fieldInUse != null) {
            request.setAttribute("message", fieldInUse);
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        User newUser = new User(0, firstName, lastName, email, username, password, null, null);

        boolean isRegistered = userService.registerUser(newUser);

        if (isRegistered) {
            request.setAttribute("message", "El usuario se registró exitosamente. Puedes iniciar sesión.");
        } else {
            request.setAttribute("message", "Error al registrar el usuario.");
        }

        request.getRequestDispatcher("register.jsp").forward(request, response);
    }
}
