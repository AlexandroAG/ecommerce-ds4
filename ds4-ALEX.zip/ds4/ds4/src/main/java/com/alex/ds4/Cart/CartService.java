package com.alex.ds4.Cart;

import com.alex.ds4.Product.Product;
import java.util.List;

public class CartService {

    private final CartRepository cartRepository;

    public CartService() {
        this.cartRepository = new CartRepository();
    }

    public Cart getActiveCartByUserId(int userId) {
        return cartRepository.getActiveCartByUserId(userId);
    }

    public Cart createCart(int userId) {
        return cartRepository.createCart(userId);
    }

    public void addProductToCart(int cartId, Product product, int quantity) {
        cartRepository.addProductToCart(cartId, product, quantity);
    }

    public CartDetails getCartItemByProductId(int cartId, int productId) {
        return cartRepository.getCartItemByProductId(cartId, productId);
    }

    public void updateCartItem(CartDetails item) {
        cartRepository.updateCartItem(item);
    }

    public void removeProductFromCart(int cartId, int productId) {
        cartRepository.removeProductFromCart(cartId, productId);
    }

    public void updateCartStatus(int cartId) {
        cartRepository.updateCartStatus(cartId);
    }

}
