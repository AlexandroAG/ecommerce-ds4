package com.alex.ds4.Order;

import java.util.List;

public class OrderService {

    private final OrderRepository orderRepository;

    public OrderService() {
        this.orderRepository = new OrderRepository();
    }

    public void createOrder(Order order) {
        orderRepository.createOrder(order);
    }
    
    public static List<Order> getOrders() {
        OrderService service = new OrderService();
        return service.orderRepository.getOrders();
    }
    
    public static List<Order> getOrdersByUserIdStatic(int userId) {
        OrderService service = new OrderService();
        return service.orderRepository.getOrdersByUserId(userId);
    }
}
