package com.alex.ds4.Order;

import com.alex.ds4.Cart.CartDetails;
import com.alex.ds4.Cart.Cart;
import com.alex.ds4.Cart.CartService;
import com.alex.ds4.Product.ProductService;
import com.alex.ds4.User.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import com.alex.ds4.Product.Product;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {

    private final OrderService orderService = new OrderService();
    private final ProductService productService = new ProductService();
    private final CartService cartService = new CartService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String shippingAddress = request.getParameter("shippingAddress");
        int paymentMethodId = Integer.parseInt(request.getParameter("paymentMethod"));
        BigDecimal vat = new BigDecimal(request.getParameter("vat"));
        BigDecimal totalAmount = new BigDecimal(request.getParameter("totalAmount"));
        BigDecimal finalTotal = new BigDecimal(request.getParameter("finalTotal"));
        

        User user = (User) session.getAttribute("user");

        List<CartDetails> cartDetailsToUse = null;
        AtomicInteger success = new AtomicInteger(0);
        if (user != null) {
            cartDetailsToUse = (List<CartDetails>) session.getAttribute("cartDetails");
            Order order = new Order(user.getId(), totalAmount, vat, shippingAddress, paymentMethodId);
            orderService.createOrder(order);

            cartDetailsToUse.stream().forEach(detail -> {
                Product product = productService.getProductById(detail.getProduct().getId());
                int newStock = product.getStock() - detail.getQuantity();
                if (productService.updateStock(detail.getProduct().getId(), newStock)) {
                    success.getAndIncrement();
                }
            });
        } else {
            Cart tempCart = (Cart) session.getAttribute("tempCart");
            cartDetailsToUse = tempCart != null ? tempCart.getCartDetails() : new ArrayList<CartDetails>();
            Order order = new Order(totalAmount, vat, shippingAddress, paymentMethodId);
            orderService.createOrder(order);

            cartDetailsToUse.stream().forEach(detail -> {
                Product product = productService.getProductById(detail.getProduct().getId());
                int newStock = product.getStock() - detail.getQuantity();
                if (productService.updateStock(detail.getProduct().getId(), newStock)) {
                    success.getAndIncrement();
                }
            });
        }

        String message;
        if (success.get() > 0) {
            message = "Compra realizada con éxito.";
            if (user != null) {
                Cart cart = cartService.getActiveCartByUserId(user.getId());
                cartService.updateCartStatus(cart.getId());
                response.sendRedirect(request.getContextPath() + "/successOrderPayment.jsp");
            } else {
                session.removeAttribute("tempCart");
                response.sendRedirect(request.getContextPath() + "/successOrderPayment.jsp");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/failOrderPayment.jsp");
        }

    }
}
