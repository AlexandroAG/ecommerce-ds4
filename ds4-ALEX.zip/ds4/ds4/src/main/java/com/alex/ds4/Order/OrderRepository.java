package com.alex.ds4.Order;

import com.alex.ds4.resources.dbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class OrderRepository {

    public void createOrder(Order order) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = dbConnection.getConnection();

            if (order.getUserId() == 0) {
                String query = "INSERT INTO orders (totalAmount, shippingAddress, vat, paymentMethodId) "
                        + "VALUES (?, ?, ?, ?)";
                ps = conn.prepareStatement(query);
                ps.setBigDecimal(1, order.getTotalAmount());
                ps.setString(2, order.getShippingAddress());
                ps.setBigDecimal(3, order.getVat());
                ps.setInt(4, order.getPaymentMethodId());
                ps.executeUpdate();
            } else {
                String query = "INSERT INTO orders (userId, totalAmount, shippingAddress, vat, paymentMethodId) "
                        + "VALUES (?, ?, ?, ?, ?)";
                ps = conn.prepareStatement(query);
                ps.setInt(1, order.getUserId());
                ps.setBigDecimal(2, order.getTotalAmount());
                ps.setString(3, order.getShippingAddress());
                ps.setBigDecimal(4, order.getVat());
                ps.setInt(5, order.getPaymentMethodId());
                ps.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(null, ps, conn);
        }

    }

    public List<Order> getOrders() {
        List<Order> orders = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = dbConnection.getConnection();
            String query = "SELECT o.id, COALESCE(u.username, 'Anónimo') AS username , o.orderDate, o.totalAmount, o.shippingAddress, o.vat, pm.name AS paymentMethod FROM orders o JOIN paymentmethods pm ON o.paymentMethodId = pm.id LEFT JOIN users u ON o.userId = u.id";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                Timestamp timestamp = rs.getTimestamp("orderDate");

                LocalDateTime orderDate = timestamp != null ? timestamp.toLocalDateTime() : null;

                Order order = new Order(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getBigDecimal("totalAmount"),
                        rs.getBigDecimal("vat"),
                        rs.getString("shippingAddress"),
                        rs.getString("paymentMethod"),
                        orderDate
                );
                orders.add(order);
            }
        } catch (SQLException e) {

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
            }
        }

        return orders;
    }
    
    public List<Order> getOrdersByUserId(int userId) {
        List<Order> orders = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = dbConnection.getConnection();
            String query = "SELECT o.id, COALESCE(u.username, 'Anónimo') AS username , o.orderDate, o.totalAmount, o.shippingAddress, o.vat, pm.name AS paymentMethod FROM orders o JOIN paymentmethods pm ON o.paymentMethodId = pm.id LEFT JOIN users u ON o.userId = u.id WHERE o.userId = ?";
            ps = conn.prepareStatement(query);
            ps.setInt(1, userId);
            rs = ps.executeQuery();
            while (rs.next()) {
                Timestamp timestamp = rs.getTimestamp("orderDate");

                LocalDateTime orderDate = timestamp != null ? timestamp.toLocalDateTime() : null;

                Order order = new Order(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getBigDecimal("totalAmount"),
                        rs.getBigDecimal("vat"),
                        rs.getString("shippingAddress"),
                        rs.getString("paymentMethod"),
                        orderDate
                );
                orders.add(order);
            }
        } catch (SQLException e) {

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
            }
        }

        return orders;
    }

    private void closeResources(ResultSet rs, PreparedStatement ps, Connection conn) {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
