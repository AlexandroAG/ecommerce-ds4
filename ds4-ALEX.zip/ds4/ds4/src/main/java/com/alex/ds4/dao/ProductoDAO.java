package com.alex.ds4.dao;

import com.alex.ds4.resources.dbConnection;
import com.alex.ds4.models.Producto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    public static List<Producto> getAllProducts() throws SQLException {
        List<Producto> products = new ArrayList<>();
        Connection connection = dbConnection.getConnection();

        String sql = "SELECT * FROM products";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            Producto product = new Producto(
                    resultSet.getInt("id"),
                    resultSet.getString("name"),
                    resultSet.getString("description"),
                    resultSet.getDouble("price"),
                    resultSet.getInt("stock"),
                    resultSet.getInt("categoryId"),
                    resultSet.getBytes("image")
            );
            products.add(product);
        }

        return products;
    }

    public static void addProduct(Producto product) throws SQLException {
        Connection connection = dbConnection.getConnection();
        String sql = "INSERT INTO products (name, description, price, stock, categoryId) VALUES (?, ?, ?, ?, ?)";

        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, product.getName());
        statement.setString(2, product.getDescription());
        statement.setDouble(3, product.getPrice());
        statement.setInt(4, product.getStock());
        statement.setInt(5, product.getCategoryId());

        statement.executeUpdate();
    }

    public static void updateProduct(Producto product) throws SQLException {
        Connection connection = dbConnection.getConnection();
        String sql = "UPDATE products SET name = ?, description = ?, price = ?, stock = ?, categoryId = ? WHERE id = ?";

        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, product.getName());
        statement.setString(2, product.getDescription());
        statement.setDouble(3, product.getPrice());
        statement.setInt(4, product.getStock());
        statement.setInt(5, product.getCategoryId());
        statement.setInt(6, product.getId());

        statement.executeUpdate();
    }

public static void deleteProduct(int productId) {
        String sql = "DELETE FROM products WHERE id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, productId);
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Producto eliminado con éxito.");
            } else {
                System.out.println("No se encontró el producto con el ID especificado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
}
}
    

 
    



