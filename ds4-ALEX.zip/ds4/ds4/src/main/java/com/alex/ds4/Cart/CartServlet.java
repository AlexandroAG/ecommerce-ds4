package com.alex.ds4.Cart;

import com.alex.ds4.User.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {

    private final CartService cartService = new CartService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user"); 

        Cart cart;

        if (user != null) {
            cart = cartService.getActiveCartByUserId(user.getId());

            if (cart == null) {
                cart = cartService.createCart(user.getId());
            }
        } else {
            cart = (Cart) session.getAttribute("tempCart");

            if (cart == null) {
                cart = new Cart(); 
                session.setAttribute("tempCart", cart); 
            }
        }

        if (cart != null) {
            List<CartDetails> cartDetails = cart.getCartDetails();
            session.setAttribute("cartDetails", cartDetails);
        }

        request.getRequestDispatcher("cart.jsp").forward(request, response);
    }
}
