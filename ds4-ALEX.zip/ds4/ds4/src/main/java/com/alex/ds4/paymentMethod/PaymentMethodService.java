package com.alex.ds4.paymentMethod;

import java.util.List;

public class PaymentMethodService {

    private final PaymentMethodRepository paymentMethodRepository;

    public PaymentMethodService() {
        this.paymentMethodRepository = new PaymentMethodRepository();
    }

    public List<PaymentMethod> getPaymentMethods() {
        return paymentMethodRepository.getPaymentMethods();
    }
}
