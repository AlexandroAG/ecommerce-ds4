package com.alex.ds4.Order;

import com.alex.ds4.paymentMethod.PaymentMethod;
import com.alex.ds4.paymentMethod.PaymentMethodService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@WebServlet("/cartToOrder")
public class CartToOrderServlet extends HttpServlet {

    private final PaymentMethodService paymentMethodService = new PaymentMethodService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String totalParam = request.getParameter("total");
        BigDecimal total = new BigDecimal(totalParam);
        BigDecimal percentage = new BigDecimal("0.07");
        BigDecimal vat = total.multiply(percentage);

        List<PaymentMethod> paymentMethods = paymentMethodService.getPaymentMethods();

        request.setAttribute("paymentMethods", paymentMethods);
        request.setAttribute("total", total);
        request.setAttribute("vat", vat);

        request.getRequestDispatcher("order.jsp").forward(request, response);
    }
}
