package com.alex.ds4.Cart;

import com.alex.ds4.Product.Product;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private Integer userId;  
    private LocalDateTime creationDate;

    private boolean status = true;

    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CartDetails> cartDetails = new ArrayList<>();

    public Cart(int id, int userId, LocalDateTime creationDate, boolean status) {
        this.id = id;
        this.userId = userId;
        this.creationDate = creationDate;
        this.status = status;
    }

    public Cart(Integer userId) {
        this.userId = userId;
        this.creationDate = LocalDateTime.now();
    }

    public Cart() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public List<CartDetails> getCartDetails() {
        return cartDetails;
    }

    public void setCartDetails(List<CartDetails> cartDetails) {
        this.cartDetails = cartDetails;
    }

    public void addProduct(Product product, int quantity) {
        for (CartDetails cartDetail : cartDetails) {
            if (cartDetail.getProduct().getId() == product.getId()) {
                cartDetail.setQuantity(cartDetail.getQuantity() + quantity);
                return;
            }
        }

        CartDetails newCartDetail = new CartDetails(this, product, quantity);
        cartDetails.add(newCartDetail);
    }

    public void deactivate() {
        this.status = false;
    }

    public CartDetails getCartItemByProductId(int productId) {
        for (CartDetails detail : this.cartDetails) {
            if (detail.getProduct().getId() == productId) {
                return detail;
            }
        }
        return null; 
    }

    public void removeProductById(int productId) {
        cartDetails.removeIf(detail -> detail.getProduct().getId() == productId);
    }

    public void updateProductQuantity(int productId, int quantity) {
        for (CartDetails detail : cartDetails) {
            if (detail.getProduct().getId() == productId) {
                detail.setQuantity(quantity);
                break;
            }
        }
    }

}
