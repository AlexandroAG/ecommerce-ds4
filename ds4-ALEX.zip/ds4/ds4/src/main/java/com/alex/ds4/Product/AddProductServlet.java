package com.alex.ds4.Product;

import com.alex.ds4.Category.Category;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;

@WebServlet("/addProduct")
@MultipartConfig(maxFileSize = 16 * 1024 * 1024) 
public class AddProductServlet extends HttpServlet {

    private final ProductService productService;

    public AddProductServlet() {
        this.productService = new ProductService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            BigDecimal price = new BigDecimal(request.getParameter("price"));
            int stock = Integer.parseInt(request.getParameter("stock"));
            int categoryId = Integer.parseInt(request.getParameter("categoryId"));

        if (price.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("El precio debe ser un número positivo.");
        }

        if (stock < 0) {
            throw new IllegalArgumentException("La cantidad en stock no puede ser negativa.");
        }

        if (categoryId < 1 || categoryId > 5) {
            throw new IllegalArgumentException("La categoría debe estar entre 1 y 5.");
        }
            Part imagePart = request.getPart("image");
            byte[] imageData = null;

            if (imagePart != null && imagePart.getSize() > 0) {
                try (InputStream inputStream = imagePart.getInputStream()) {
                    imageData = inputStream.readAllBytes();
                }
            }

            Category category = new Category(categoryId, null);

            Product product = new Product(0, name, description, price, stock, category, imageData);

            boolean isAdded = productService.addProduct(product);

            if (isAdded) {
                request.setAttribute("message", "Producto agregado correctamente.");
                request.setAttribute("success", true);
            } else {
                request.setAttribute("message", "Hubo un error al agregar el producto.");
                request.setAttribute("success", false);
            }
            
            request.getRequestDispatcher("/addProductConfirmation.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Hubo un error al procesar la solicitud.");
            request.setAttribute("success", false);
            request.getRequestDispatcher("/addProductConfirmation.jsp").forward(request, response);
        }
    }
}
