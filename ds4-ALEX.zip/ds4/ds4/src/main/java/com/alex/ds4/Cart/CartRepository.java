package com.alex.ds4.Cart;

import com.alex.ds4.Product.Product;
import com.alex.ds4.Product.ProductService;
import com.alex.ds4.resources.dbConnection;
import java.math.BigDecimal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartRepository {

    private final ProductService productService = new ProductService();

    public Cart getActiveCartByUserId(int userId) {
        Cart cart = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = dbConnection.getConnection();
            String query = "SELECT * FROM Carts WHERE userId = ? AND status = 1 ORDER BY creationDate DESC LIMIT 1";
            ps = conn.prepareStatement(query);
            ps.setInt(1, userId);
            rs = ps.executeQuery();

            if (rs.next()) {
                int cartId = rs.getInt("id");
                cart = new Cart(cartId, userId, null, true);
                cart.setCartDetails(getCartDetailsByCartId(cartId));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, ps, conn);
        }

        return cart;
    }

    public Cart createCart(int userId) {
        Cart cart = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet generatedKeys = null;

        try {
            conn = dbConnection.getConnection();
            String query = "INSERT INTO Carts (userId) VALUES (?)";
            ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, userId);
            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                generatedKeys = ps.getGeneratedKeys();
                if (generatedKeys.next()) {
                    cart = new Cart(generatedKeys.getInt(1), userId, null, true);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(generatedKeys, ps, conn);
        }

        return cart;
    }

    public void addProductToCart(int cartId, Product product, int quantity) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = dbConnection.getConnection();
            String query = "INSERT INTO CartDetails (cartId, productId, quantity, price) VALUES (?, ?, ?, ?)";
            ps = conn.prepareStatement(query);
            ps.setInt(1, cartId);
            ps.setInt(2, product.getId());
            ps.setInt(3, quantity);
            ps.setBigDecimal(4, product.getPrice());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(null, ps, conn);
        }
    }

    private List<CartDetails> getCartDetailsByCartId(int cartId) {
        List<CartDetails> cartDetailsList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = dbConnection.getConnection();
            String query = "SELECT * FROM CartDetails WHERE cartId = ?";
            ps = conn.prepareStatement(query);
            ps.setInt(1, cartId);
            rs = ps.executeQuery();

            while (rs.next()) {
                int detailId = rs.getInt("id");
                int productId = rs.getInt("productId");
                int quantity = rs.getInt("quantity");
                BigDecimal price = rs.getBigDecimal("price");

                // Crear un CartDetails
                CartDetails cartDetail = new CartDetails(detailId, null, null, productId, quantity, price, true);

                cartDetail.setProduct(productService.getProductById(productId));
                cartDetailsList.add(cartDetail);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, ps, conn);
        }

        return cartDetailsList;
    }

    public CartDetails getCartItemByProductId(int cartId, int productId) {
        CartDetails cartItem = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = dbConnection.getConnection();
            String query = "SELECT * FROM CartDetails WHERE cartId = ? AND productId = ?";
            ps = conn.prepareStatement(query);
            ps.setInt(1, cartId);
            ps.setInt(2, productId);
            rs = ps.executeQuery();

            if (rs.next()) {
                cartItem = new CartDetails();
                cartItem.setId(rs.getInt("id"));
                cartItem.setCardId(cartId);
                cartItem.setProductId(rs.getInt("productId"));
                cartItem.setQuantity(rs.getInt("quantity"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(rs, ps, conn);
        }

        return cartItem;
    }

    public void updateCartItem(CartDetails item) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = dbConnection.getConnection();
            String query = "UPDATE CartDetails SET quantity = ? WHERE id = ?";
            ps = conn.prepareStatement(query);
            ps.setInt(1, item.getQuantity());
            ps.setInt(2, item.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(null, ps, conn);
        }
    }

    public void removeProductFromCart(int cartId, int productId) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = dbConnection.getConnection();
            String query = "DELETE FROM CartDetails WHERE cartId = ? AND productId = ?";
            ps = conn.prepareStatement(query);
            ps.setInt(1, cartId);
            ps.setInt(2, productId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(null, ps, conn);
        }
    }

    public boolean updateCartStatus(int cartId) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = dbConnection.getConnection();

            String query = "UPDATE carts SET status = 0 WHERE id = ?";

            ps = conn.prepareStatement(query);
            ps.setInt(1, cartId);

            int rowsAffected = ps.executeUpdate();

            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false; 
        } finally {
            closeResources(null, ps, conn);
        }
    }

    private void closeResources(ResultSet rs, PreparedStatement ps, Connection conn) {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
