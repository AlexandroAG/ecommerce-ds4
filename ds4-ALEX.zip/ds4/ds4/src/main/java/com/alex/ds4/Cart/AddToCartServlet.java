package com.alex.ds4.Cart;

import com.alex.ds4.Product.Product;
import com.alex.ds4.Product.ProductService;
import com.alex.ds4.User.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/addToCart")
public class AddToCartServlet extends HttpServlet {

    private final ProductService productService = new ProductService();
    private final CartService cartService = new CartService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productIdParam = request.getParameter("productId");
        String quantityParam = request.getParameter("quantity");

        if (productIdParam != null && quantityParam != null) {
            try {
                int productId = Integer.parseInt(productIdParam);
                int quantity = Integer.parseInt(quantityParam);

                Product product = productService.getProductById(productId);

                if (product != null) {
                    HttpSession session = request.getSession();
                    User user = (User) session.getAttribute("user"); 

                    if (user != null) {
                        Cart cart = cartService.getActiveCartByUserId(user.getId());
                        if (cart == null) {
                            cart = cartService.createCart(user.getId());
                        }

                        CartDetails existingItem = cartService.getCartItemByProductId(cart.getId(), productId);
                        if (existingItem != null) {
                            existingItem.setQuantity(existingItem.getQuantity() + quantity);
                            cartService.updateCartItem(existingItem); 
                        } else {
                            cartService.addProductToCart(cart.getId(), product, quantity);
                        }

                        response.sendRedirect(request.getContextPath() + "/productDetails?id=" + productIdParam);

                    } else {
                        Cart tempCart = (Cart) session.getAttribute("tempCart");

                        if (tempCart == null) {
                            tempCart = new Cart(); 
                            session.setAttribute("tempCart", tempCart);
                        }

                        CartDetails existingItem = tempCart.getCartItemByProductId(productId);
                        if (existingItem != null) {
                            existingItem.setQuantity(existingItem.getQuantity() + quantity);
                        } else {
                            tempCart.addProduct(product, quantity);
                        }

                        response.sendRedirect(request.getContextPath() + "/productDetails?id=" + productIdParam);
                    }

                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Producto no encontrado");
                }

            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Datos de producto o cantidad no válidos");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Faltan parámetros para agregar al carrito");
        }
    }
}
