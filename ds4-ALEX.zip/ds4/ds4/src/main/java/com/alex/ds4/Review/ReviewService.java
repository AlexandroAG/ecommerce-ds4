package com.alex.ds4.Review;

import java.util.List;

public class ReviewService {

    private final ReviewRepository reviewRepository = new ReviewRepository();

    public List<Review> getProductReviews(int productId) {
        return reviewRepository.getProductReviews(productId);
    }

    public void addReview(Review review) {
        reviewRepository.addReview(review);
    }
}
