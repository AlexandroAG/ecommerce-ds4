package com.alex.ds4.Cart;

import com.alex.ds4.User.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/removeFromCart")
public class RemoveFromCartServlet extends HttpServlet {

    private final CartService cartService = new CartService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productIdParam = request.getParameter("productId");
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (productIdParam != null) {
            try {
                int productId = Integer.parseInt(productIdParam);

                if (user != null) {
                    Cart cart = cartService.getActiveCartByUserId(user.getId());
                    if (cart != null) {
                        cartService.removeProductFromCart(cart.getId(), productId);
                    }
                } else {
                    Cart tempCart = (Cart) session.getAttribute("tempCart");
                    if (tempCart != null) {
                        tempCart.removeProductById(productId);
                    }
                }

            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID de producto no válido");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Falta el parámetro de ID del producto");
        }

        response.sendRedirect(request.getContextPath() + "/cart");
    }
}
