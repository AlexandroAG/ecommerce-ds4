package com.alex.ds4.Review;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/productReviews")
public class ReviewServlet extends HttpServlet {

    private final ReviewService reviewService = new ReviewService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productIdParam = request.getParameter("productId");
        String userIdParam = request.getParameter("userId");
        String comment = request.getParameter("comment");
        String ratingParam = request.getParameter("rating");

        if (productIdParam != null && comment != null && ratingParam != null) {
            try {
                int rating = Integer.parseInt(ratingParam);
                Review review;
                int productId = Integer.parseInt(productIdParam);
                if (rating < 1 || rating > 5) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Rating debe estar entre 1 y 5");
                    return;
                }
                if ("null".equals(userIdParam)) {
                    review = new Review(0, productId, comment, rating);
                    reviewService.addReview(review);
                } else if (!"null".equals(userIdParam)) {
                    review = new Review(0, productId, Integer.parseInt(userIdParam), comment, rating);
                    reviewService.addReview(review);
                }

                response.sendRedirect(request.getContextPath() + "/productDetails?id=" + productIdParam);
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Datos de entrada no válidos");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Faltan parámetros para agregar la reseña");
        }
    }
}
