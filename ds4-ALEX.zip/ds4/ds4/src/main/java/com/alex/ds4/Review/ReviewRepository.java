package com.alex.ds4.Review;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.alex.ds4.resources.dbConnection;
import java.time.LocalDateTime;

public class ReviewRepository {

    public List<Review> getProductReviews(int productId) {
        List<Review> reviews = new ArrayList<>();
        try (Connection conn = dbConnection.getConnection()) {
            String query = "SELECT r.id, r.productId, r.userId, r.comment, r.rating, r.reviewDate, u.username AS username "
                    + "FROM Reviews r LEFT JOIN Users u ON r.userId = u.id "
                    + "WHERE r.productId = ?";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setInt(1, productId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Timestamp timestamp = rs.getTimestamp("reviewDate");

                        LocalDateTime reviewDate = timestamp != null ? timestamp.toLocalDateTime() : null;

                        Review review = new Review(
                                rs.getInt("id"),
                                rs.getInt("productId"),
                                rs.getInt("userId"),
                                rs.getString("comment"),
                                rs.getInt("rating"),
                                reviewDate, // Aquí asignas el LocalDateTime
                                rs.getString("userName") // Asignar el nombre del usuario
                        );
                        reviews.add(review);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reviews;
    }

    public void addReview(Review review) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = dbConnection.getConnection();
            if (review.getUserId() == 0) {
                String query = "INSERT INTO Reviews (productId, comment, rating) VALUES (?, ?, ?)";
                ps = conn.prepareStatement(query);
                ps.setInt(1, review.getProductId());
                ps.setString(2, review.getComment());
                ps.setInt(3, review.getRating());

                ps.executeUpdate();
            }
            String query = "INSERT INTO Reviews (productId, userId, comment, rating) VALUES (?, ?, ?, ?)";
            ps = conn.prepareStatement(query);
            ps.setInt(1, review.getProductId());
            ps.setInt(2, review.getUserId());
            ps.setString(3, review.getComment());
            ps.setInt(4, review.getRating());

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeResources(null, ps, conn);
        }
    }

    private void closeResources(ResultSet rs, PreparedStatement ps, Connection conn) {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
