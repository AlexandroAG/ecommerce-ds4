package com.alex.ds4.Cart;

import com.alex.ds4.User.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Enumeration;

@WebServlet("/updateCart")
public class UpdateCartServlet extends HttpServlet {

    private final CartService cartService = new CartService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        Enumeration<String> parameterNames = request.getParameterNames();

        while (parameterNames.hasMoreElements()) {
            String paramName = parameterNames.nextElement();
            if (paramName.startsWith("quantity_")) {
                try {
                    int productId = Integer.parseInt(paramName.substring(9));
                    int quantity = Integer.parseInt(request.getParameter(paramName));

                    if (user != null) {
                        Cart cart = cartService.getActiveCartByUserId(user.getId());
                        if (cart != null) {
                            CartDetails item = cartService.getCartItemByProductId(cart.getId(), productId);
                            if (item != null) {
                                item.setQuantity(quantity);
                                cartService.updateCartItem(item);
                            }
                        }
                    } else {
                        Cart tempCart = (Cart) session.getAttribute("tempCart");
                        if (tempCart != null) {
                            CartDetails item = tempCart.getCartItemByProductId(productId);
                            if (item != null) {
                                item.setQuantity(quantity);
                            }
                        }
                    }

                } catch (NumberFormatException e) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Datos de producto o cantidad no válidos");
                }
            }
        }

        response.sendRedirect(request.getContextPath() + "/cart");
    }
}
