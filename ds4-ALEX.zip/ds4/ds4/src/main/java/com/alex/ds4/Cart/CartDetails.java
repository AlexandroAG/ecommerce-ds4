package com.alex.ds4.Cart;

import com.alex.ds4.Product.Product;
import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class CartDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cartId", nullable = false)
    private Cart cart;

    private Product product;
    private int productId;
    private int quantity;
    private int cardId;

    @Column(precision = 9, scale = 2)
    private BigDecimal price;

    private boolean status = true; 

    public CartDetails() {
    }

    public CartDetails(int id, Cart cart, Product product, int productId, int quantity, BigDecimal price, boolean status) {
        this.id = id;
        this.cart = cart;
        this.product = product;
        this.productId = productId;
        this.quantity = quantity;
        this.price = price;
        this.status = status;
    }

    public CartDetails(Cart cart, Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
        this.cart = cart;
    }

    public CartDetails(int id, int cardId, int productId, int quantity) {
        this.id = id;
        this.productId = productId;
        this.quantity = quantity;
        this.cardId = cardId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdCardId() {
        return cardId;
    }

    public void setCardId(int cardId) {
        this.cardId = cardId;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void deactivate() {
        this.status = false;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}
