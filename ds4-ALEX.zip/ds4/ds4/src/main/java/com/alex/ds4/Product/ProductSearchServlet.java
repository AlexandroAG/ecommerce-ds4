package com.alex.ds4.Product;

import java.util.List;
import com.alex.ds4.Category.Category;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/searchProducts")
public class ProductSearchServlet extends HttpServlet {

    private final ProductService productService;

    public ProductSearchServlet() {
        this.productService = new ProductService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String search = request.getParameter("search");
        String category = request.getParameter("category");
        String sort = request.getParameter("sort");
        
        if (search == null || search.isEmpty()) {
            search = "";
        }

        if (category == null || category.isEmpty()) {
            category = "";
        }

        if (sort == null || sort.isEmpty()) {
            sort = "name_asc"; 
        }
        
        List<Category> categories = productService.getCategories();
        request.setAttribute("categories", categories);

        List<Product> products = productService.searchProducts(search, category, sort);
        
        request.setAttribute("products", products);

        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}
