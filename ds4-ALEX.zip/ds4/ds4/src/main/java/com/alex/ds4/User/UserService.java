package com.alex.ds4.User;

import com.alex.ds4.resources.dbConnection;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.Connection;
import java.sql.SQLException;

public class UserService {

    private final UserRepository userRepository;

    public UserService() {
        this.userRepository = new UserRepository();
    }

    /**
     * Registra un nuevo usuario después de validar que no exista un duplicado.
     *
     * @param user El usuario a registrar.
     * @return true si el registro fue exitoso, false si el usuario o correo ya
     * existen.
     */
    public boolean registerUser(User user) {
        if (user == null || user.getUsername().isEmpty() || user.getEmail().isEmpty() || user.getPassword().isEmpty()) {
            throw new IllegalArgumentException("El nombre de usuario, correo electrónico y la contraseña son obligatorios.");
        }

        try (Connection connection = dbConnection.getConnection()) {
            if (userRepository.isUsernameExist(connection, user.getUsername())) {
                return false;  
            }

            if (userRepository.isEmailExist(connection, user.getEmail())) {
                return false;  
            }
            String encryptedPassword = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
            user.setPassword(encryptedPassword);

            boolean registrationSuccess = userRepository.registerUser(connection, user);

            return registrationSuccess;  

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            return false;
        }
    }
}
