package com.alex.ds4.User;

import com.alex.ds4.resources.dbConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/loginUser")
public class UserLoginServlet extends HttpServlet {

    private final UserRepository userRepository;

    public UserLoginServlet() {
        this.userRepository = new UserRepository();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String usernameOrEmail = request.getParameter("usernameOrEmail");
        String password = request.getParameter("password");

        if (usernameOrEmail == null || password == null || usernameOrEmail.isEmpty() || password.isEmpty()) {
            request.setAttribute("message", "Por favor, ingrese ambos campos.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        User user = null;
        try (Connection connection = dbConnection.getConnection()) {
            if (userRepository.isUsernameExist(connection, usernameOrEmail)) {
                user = userRepository.getUserByUsername(connection, usernameOrEmail);
            } else if (userRepository.isEmailExist(connection, usernameOrEmail)) {
                user = userRepository.getUserByEmail(connection, usernameOrEmail);
            }
        } catch (SQLException e) {
            request.setAttribute("message", "Error al verificar los datos. Intenta nuevamente.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        if (user == null || !BCrypt.checkpw(password, user.getPassword())) {
            request.setAttribute("message", "Nombre de usuario, correo electrónico o contraseña incorrectos.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        HttpSession session = request.getSession();
        session.setAttribute("user", user);

        if (null == user.getRole()) {
            response.sendRedirect("login.jsp");
        } else {
            switch (user.getRole()) {
                case admin ->
                    response.sendRedirect("dashboard.jsp");
                case customer ->
                    response.sendRedirect("index.jsp");
                default ->
                    response.sendRedirect("login.jsp");
            }
        }
    }
}
