package com.alex.ds4.Product;

import com.alex.ds4.Category.Category;
import java.sql.*;
import java.util.*;
import com.alex.ds4.resources.dbConnection;

public class ProductRepository {

    public List<Product> searchProducts(String search, String category, String sort) {
        List<Product> products = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = dbConnection.getConnection();
            String query = "SELECT p.id, p.name, p.description, p.price, p.stock, c.id AS categoryId, c.name AS categoryName, p.image "
                    + "FROM Products p JOIN Categories c ON p.categoryId = c.id WHERE 1=1 ";

            if (search != null && !search.isEmpty()) {
                query += "AND p.name LIKE ? ";
                    
            }

            if (category != null && !category.isEmpty()) {
                query += "AND c.id = ? ";
            }

            if (sort != null) {
                switch (sort) {
                    case "name_asc" ->
                        query += "ORDER BY p.name ASC";
                    case "name_desc" ->
                        query += "ORDER BY p.name DESC";
                    case "price_asc" ->
                        query += "ORDER BY p.price ASC";
                    case "price_desc" ->
                        query += "ORDER BY p.price DESC";
                }
            }

            ps = conn.prepareStatement(query);
            int paramIndex = 1;

            if (search != null && !search.isEmpty()) {
                String[] searchTerms = search.split(" ");
                for (String term : searchTerms) {
                    ps.setString(paramIndex++, "%" + term + "%");
                }
            }

            if (category != null && !category.isEmpty()) {
                ps.setInt(paramIndex++, Integer.parseInt(category));
            }

            rs = ps.executeQuery();
            while (rs.next()) {
                Category categoryObj = new Category(
                        rs.getInt("categoryId"),
                        rs.getString("categoryName")
                );

                Product product = new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getBigDecimal("price"),
                        rs.getInt("stock"),
                        categoryObj,
                        null
                );
                products.add(product);
            }
        } catch (NumberFormatException | SQLException e) {

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
            }
        }

        return products;
    }

    public List<Category> getCategories() {
        List<Category> categories = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = dbConnection.getConnection();
            String query = "SELECT id, name FROM Categories";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                Category category = new Category(
                        rs.getInt("id"),
                        rs.getString("name")
                );
                categories.add(category);
            }
        } catch (SQLException e) {

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
            }
        }

        return categories;
    }

    public byte[] getProductImage(int productId) {
        byte[] imageData = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = dbConnection.getConnection();
            String query = "SELECT image FROM Products WHERE id = ?";
            ps = conn.prepareStatement(query);
            ps.setInt(1, productId);
            rs = ps.executeQuery();

            if (rs.next()) {
                imageData = rs.getBytes("image");
            }
        } catch (SQLException e) {

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
            }
        }

        return imageData;
    }

    public Product getProductById(int productId) {
        Product product = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = dbConnection.getConnection();
            String query = "SELECT p.id, p.name, p.description, p.price, p.stock, c.id AS categoryId, c.name AS categoryName, p.image "
                    + "FROM Products p JOIN Categories c ON p.categoryId = c.id WHERE p.id = ?";
            ps = conn.prepareStatement(query);
            ps.setInt(1, productId);
            rs = ps.executeQuery();

            if (rs.next()) {
                Category categoryObj = new Category(
                        rs.getInt("categoryId"),
                        rs.getString("categoryName")
                );

                product = new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getBigDecimal("price"),
                        rs.getInt("stock"),
                        categoryObj,
                        null
                );
            }
        } catch (SQLException e) {
            e.printStackTrace(); 
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return product;
    }

    private void closeResources(ResultSet rs, PreparedStatement ps, Connection conn) {
        try {
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            if (ps != null) {
                ps.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean updateStock(int productId, int newStock) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = dbConnection.getConnection();

            String query = "UPDATE products SET stock = ? WHERE id = ?";

            ps = conn.prepareStatement(query);
            ps.setInt(1, newStock); 
            ps.setInt(2, productId); 

            int rowsAffected = ps.executeUpdate();

            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false; 
        } finally {
            closeResources(null, ps, conn);
        }
    }

    public boolean addProduct(Product product) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = dbConnection.getConnection();

            String query = "INSERT INTO Products (name, description, price, stock, categoryId, image) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";

            ps = conn.prepareStatement(query);
            ps.setString(1, product.getName());
            ps.setString(2, product.getDescription());
            ps.setBigDecimal(3, product.getPrice());
            ps.setInt(4, product.getStock());
            ps.setInt(5, product.getCategory().getId());
            ps.setBytes(6, product.getImage());

            int rowsAffected = ps.executeUpdate();

            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false; 
        } finally {
            closeResources(null, ps, conn);
        }
    }
  

    
  }


