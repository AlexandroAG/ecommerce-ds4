package com.alex.ds4.User;

import com.alex.ds4.resources.dbConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username"); 
        String password = request.getParameter("password");

        boolean isValidUser = false;
        try (Connection connection = dbConnection.getConnection()) {
            String sql = "SELECT password FROM usuarios WHERE username = ?"; 
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, username); 

                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String storedPassword = rs.getString("password");

                    isValidUser = storedPassword.equals(password); 
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (isValidUser) {
            HttpSession session = request.getSession();
            session.setAttribute("username", username);

            response.sendRedirect("home");
        } else {
            
            request.setAttribute("error", "Credenciales incorrectas");
            request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
        }
    }
}
