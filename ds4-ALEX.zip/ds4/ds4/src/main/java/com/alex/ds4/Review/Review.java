package com.alex.ds4.Review;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int productId;
    private int userId;
    private String comment;
    private int rating; 
    private LocalDateTime reviewDate;
    private String username;
    private String formattedDate;

    public Review(int id, int productId, int userId, String comment, int rating, LocalDateTime reviewDate, String username) {
        this.id = id;
        this.productId = productId;
        this.userId = userId;
        this.comment = comment;
        this.rating = rating;
        this.reviewDate = reviewDate;
        this.username = username;
        this.formattedDate = formatReviewDate(reviewDate);
    }

    public Review(int id, int productId, int userId, String comment, int rating) {
        this.id = id;
        this.productId = productId;
        this.userId = userId;
        this.comment = comment;
        this.rating = rating;
    }

    public Review(int id, int productId, String comment, int rating) {
        this.id = id;
        this.productId = productId;
        this.comment = comment;
        this.rating = rating;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public LocalDateTime getReviewDate() {
        return reviewDate;
    }

    public void setReviewDate(LocalDateTime reviewDate) {
        this.reviewDate = reviewDate;
        this.formattedDate = formatReviewDate(reviewDate);
    }

    private String formatReviewDate(LocalDateTime reviewDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return reviewDate.format(formatter);
    }

    public String getFormattedDate() {
        return formattedDate;
    }

}
