package com.alex.ds4.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.util.Iterator;

@WebServlet("/productImage")
public class ProductImageServlet extends HttpServlet {
    private final ProductService productService = new ProductService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productIdParam = request.getParameter("id");

        if (productIdParam != null) {
            try {
                int productId = Integer.parseInt(productIdParam);

                byte[] imageData = productService.getProductImage(productId);

                if (imageData != null) {
                    String imageType = getImageType(imageData);

                    if (imageType != null) {
                        response.setContentType("image/" + imageType.toLowerCase());

                        try (BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream())) {
                            bos.write(imageData);
                            bos.flush();
                        }
                    } else {
                        response.sendError(HttpServletResponse.SC_UNSUPPORTED_MEDIA_TYPE, "Tipo de imagen no soportado");
                    }
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Imagen no encontrada para el producto ID: " + productId);
                }
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID de producto no válido");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID de producto no proporcionado");
        }
    }

    private String getImageType(byte[] imageData) {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(imageData)) {
            ImageInputStream iis = ImageIO.createImageInputStream(bais);
            Iterator<ImageReader> readers = ImageIO.getImageReaders(iis);

            if (readers.hasNext()) {
                ImageReader reader = readers.next();
                return reader.getFormatName();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
